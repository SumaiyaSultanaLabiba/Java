interface PaymentGateway {
    
    boolean processPayment(double amount) ;
    boolean refund(double amount) ;
}
