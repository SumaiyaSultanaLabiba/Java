class CreditCardPayment extends AbstractPayment implements PaymentGateway
{

  CreditCardPayment(String a)
    {
      this.accountIdentifier=a;
      this.lastTransactionAmount=0;
    }

  @Override  
  public boolean processPayment(double amount)
  {
    boolean returnvalue=this.validateDetails();
    if(returnvalue) {System.out.println("Charged $200.00 to credit card "+this.accountIdentifier); this.lastTransactionAmount=200.00;}
    return returnvalue;
  }

  @Override
  public boolean refund(double amount)
  {
    System.out.println("Refund of $50.00 processed via CreditCardPayment ");
    return true;
  }

  @Override
  public void setAccountIdentifier(String s)
  {
    this.accountIdentifier=s;
  }

  @Override
  public void recordTransaction(double amount)
   {
     this.lastTransactionAmount=amount;
   }

   @Override
   public boolean validateDetails()
   {
    if(this.accountIdentifier.matches("([0-9]{4}-){3}+[0-9]{4}"))
    {
      return true;
    }
    System.out.println("Invalid credit card details: "+this.accountIdentifier);
    return false;
   }
}
