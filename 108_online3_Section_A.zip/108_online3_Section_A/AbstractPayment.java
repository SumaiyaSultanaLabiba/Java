abstract  class AbstractPayment {
    
    public String accountIdentifier; 
    public double lastTransactionAmount; 

   abstract public void setAccountIdentifier(String s);
   public double getLastTransactionAmount() {return this.lastTransactionAmount;}
   abstract public void recordTransaction(double amount);
   abstract public boolean validateDetails();
}
