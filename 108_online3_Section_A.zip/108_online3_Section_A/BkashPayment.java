class BkashPayment extends AbstractPayment implements PaymentGateway{

    BkashPayment(String a)
    {
      this.accountIdentifier=a;
      this.lastTransactionAmount=0;
    }

    @Override
    public boolean processPayment(double amount)
  {
    boolean returnvalue=this.validateDetails();
    if(returnvalue) {System.out.println("Charged $200.00 from Bkash number "+this.accountIdentifier); this.lastTransactionAmount=200.00;}
    return returnvalue;
  }

  @Override
  public boolean refund(double amount)
  {
    System.out.println("Refund of $50.00 processed via BkashPayment ");
    return true;
  }

  @Override
  public void setAccountIdentifier(String s)
  {
    this.accountIdentifier=s;
  }

  @Override
  public void recordTransaction(double amount)
   {
     this.lastTransactionAmount=amount;
   }

   @Override
   public boolean validateDetails()
   {
    if(this.accountIdentifier.length()==11 && this.accountIdentifier.startsWith("01") && this.accountIdentifier.matches("\\d+"))
    {
      return true;
    }
    System.out.println("Invalid Bkash number: "+this.accountIdentifier);
    return false;
   }
}
