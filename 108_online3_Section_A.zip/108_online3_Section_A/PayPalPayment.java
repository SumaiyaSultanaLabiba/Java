class PayPalPayment  extends AbstractPayment implements PaymentGateway{

    PayPalPayment(String a)
    {
      this.accountIdentifier=a;
      this.lastTransactionAmount=0;
    }
    
    @Override
    public boolean processPayment(double amount)
  {
    boolean returnvalue=this.validateDetails();
    if(returnvalue) {System.out.println("Processed $200.00 via PayPal account "+this.accountIdentifier); this.lastTransactionAmount=200.00;}
    return returnvalue;
  }

  @Override
  public boolean refund(double amount)
  {
    System.out.println("Refund of $50.00 processed via PayPalPayment ");
    return true;
  }

  @Override
  public void setAccountIdentifier(String s)
  {
    this.accountIdentifier=s;
  }

  @Override
  public void recordTransaction(double amount)
   {
     this.lastTransactionAmount=amount;
   }

   @Override
   public boolean validateDetails()
   {
    if(this.accountIdentifier.matches("[a-z]+@+[a-z]+.+[a-z]"))
    {
      return true;
    }
    System.out.println("Invalid PayPal account email: "+this.accountIdentifier);
    return false;
   }
}
