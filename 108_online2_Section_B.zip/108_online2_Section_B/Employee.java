public class Employee
{
    private int employee_ID;
    private String name;
    private int days_present;

    public Employee(int employee_ID, String name, int days_present)
    {
        this.employee_ID=employee_ID;
        this.name=name;
        this.days_present=days_present;
    }

    public void display()
    {
        System.out.print("Name: "+this.name);
        System.out.print(", ID: "+this.employee_ID);
        System.out.println(", Days Present: "+this.days_present);
    }

    public void mark_attendance()
    {
        this.days_present++;
        System.out.println("Days of presence is incresed from "+(this.days_present-1)+"to "+this.days_present);
    }

    public void correct_attendance()
    {
        if(this.days_present>0) this.days_present--;
        else {System.out.println("Days of presence is already zero.\n");}
    }

    public int getID()
    {
        return this.employee_ID;
    }
}