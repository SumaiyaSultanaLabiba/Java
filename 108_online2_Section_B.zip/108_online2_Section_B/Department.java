public class Department
{
    private int department_ID;
    private int maximum_number_of_employees;
    private Employee department_employees[];
    private int current_number_of_employees;
    
    public Department(int department_ID, int maximum_number_of_employees)
    {
        this.department_ID=department_ID;
        this.maximum_number_of_employees=maximum_number_of_employees;
        this.department_employees=new Employee[this.maximum_number_of_employees];
        this.current_number_of_employees=0;
    }

    public void display()
    {
        System.out.println("Department ID: "+this.department_ID);
        System.out.println("Number of employees: "+this.current_number_of_employees);
        System.out.println("Information about all employees: ");
        if(this.current_number_of_employees==0)
        {
            System.out.println("No employees registered.\n");
            return;
        }
        for(int i=0; i<this.current_number_of_employees; i++)
        {
            this.department_employees[i].display();
            System.out.println("\n");
        }
    }

    public void mark_attendance(int employee_ID)
    {
       for(int i=0; i<this.current_number_of_employees; i++)
       {
        if(this.department_employees[i].getID()==employee_ID)
        {
            this.department_employees[i].mark_attendance();
            return;
        }
       }
    }

    public void correct_attendance(int employee_ID)
    {
       for(int i=0; i<this.current_number_of_employees; i++)
       {
        if(this.department_employees[i].getID()==employee_ID)
        {
            this.department_employees[i].correct_attendance();
            return;
        }
       }
    }

    public void addEmployee(Employee new_Employee)
    {
        this.department_employees[this.current_number_of_employees]=new_Employee;
        this.current_number_of_employees++;
    }
}