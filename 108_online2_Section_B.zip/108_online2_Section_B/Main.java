import java.util.*;


public class Main
{
    public static void main(String[] args)
    {
        Scanner scan=new Scanner(System.in);
        int number_of_departments;
        number_of_departments=Integer.parseInt(args[0]);
        while(number_of_departments>10)
        {
          System.out.print("Number of departements under an organization cannot exceed 10, enter correctly: ");
          number_of_departments=scan.nextInt();
          scan.nextLine();
        }
        Department organization[]=new Department[number_of_departments];
        for(int i=0; i<number_of_departments; i++)
        {
            int department_ID= (i+1);
            System.out.println("The department ID: "+department_ID);
            System.out.println("===================");
            System.out.print("Enter the number of employees in the department "+(i+1)+":  ");
            int number_of_employees=scan.nextInt();
            scan.nextLine();
            while(number_of_employees>50)
            {
              System.out.print("Number of employees under a department cannot exceed 50, enter correctly: ");
              number_of_employees=scan.nextInt();
              scan.nextLine();
            }
            Department current_department=new Department(department_ID, number_of_employees);
            for(int j=0; j<number_of_employees; j++)
            {
                int employee_ID;
                String name;
                int days_present;
                System.out.print("Enter the ID of employee "+(j+1)+": ");
                employee_ID=scan.nextInt();
                scan.nextLine();
                System.out.print("Enter the name of employee "+(i+1)+": ");
                name=scan.nextLine();
                System.out.print("Enter the days of presence of employee "+(i+1)+": ");
                days_present=scan.nextInt();
                scan.nextLine();
                Employee current_employee=new Employee(employee_ID, name, days_present);
                current_department.addEmployee(current_employee);
            }
            organization[i]=current_department;
            System.out.println("\n");
        }


        while(true)
        {
            System.out.println("Choose any option: ");
            System.out.println("1. Mark Attendance (Increase days) ");
            System.out.println("2. Correct Attendance (decrease days) ");
            System.out.println("3. Display All Department Info ");
            System.out.println("4. Exit ");
            int option=scan.nextInt();
            scan.nextLine();

            if(option==1)
            {
              System.out.print("Enter the department ID: ");
              int department_ID=scan.nextInt();
              scan.nextLine();
              System.out.print("Enter the employee ID: ");
              int employee_ID=scan.nextInt();
              scan.nextLine();
              organization[department_ID-1].mark_attendance(employee_ID);
            }

            else if(option==2)
            {
              System.out.print("Enter the department ID: ");
              int department_ID=scan.nextInt();
              scan.nextLine();
              System.out.print("Enter the employee ID: ");
              int employee_ID=scan.nextInt();
              scan.nextLine();
              organization[department_ID-1].correct_attendance(employee_ID);
            }

            else if(option==3)
            {
              for(int i=0; i<number_of_departments; i++)
              {
                organization[i].display();
              }
            }

            else if(option==4)
            {
                break;
            }

            System.out.println("\n\n");
        }

        scan.close();
    }
}
