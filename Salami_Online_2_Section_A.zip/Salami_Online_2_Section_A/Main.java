import java.util.*;

public class Main
{
    public static void main(String[] args)
    {
        System.out.println("Parsing command line arguments...");
        int num_courses=Integer.parseInt(args[0]);
        int num_students=Integer.parseInt(args[1]);
        System.out.println("Number of Courses: "+num_courses);
        System.out.println("Number of Students: "+num_students);
        System.out.println("---\n");

        String course_name;
        double course_credit;
        Scanner scan_tool=new Scanner(System.in);
        Course[] all_courses=new Course[num_courses];
        for(int i=0; i<num_courses; i++)
        {
          System.out.println("Course "+(i+1));
          System.out.print("Enter Course name: ");
          course_name=scan_tool.nextLine();
          System.out.print("Enter Course credit: ");
          course_credit=scan_tool.nextFloat();
          all_courses[i]=new Course(course_name, course_credit);
          scan_tool.nextLine();
        }
        System.out.println("---");

        
        Student[] all_students=new Student[num_students];
        for(int i=0; i<num_students; i++)
        {
          String student_name;
          double[] student_grades=new double[num_courses];
          System.out.print("Enter name of Student "+(i+1)+": ");
          student_name=scan_tool.nextLine();
          for(int j=0; j<num_courses; j++)
          {
            System.out.print("Enter marks for "+all_courses[j].get_name()+":");
            student_grades[j]=scan_tool.nextFloat();
            if(student_grades[j]>=80 && student_grades[j]<=100) {student_grades[j]=4;}
            else if(student_grades[j]>=70 && student_grades[j]<=79) {student_grades[j]=3.75;}
            else if(student_grades[j]>=60 && student_grades[j]<=69) {student_grades[j]=3.5;}
            else if(student_grades[j]>=50 && student_grades[j]<=59) {student_grades[j]=3.25;}
            else if(student_grades[j]>=40 && student_grades[j]<=49) {student_grades[j]=2.5;}
            else if(student_grades[j]<40) {student_grades[j]=0;}
            else ;
          }
          all_students[i]=new Student(student_name, student_grades, all_courses, num_courses);
          scan_tool.nextLine();
          System.out.println("\n");
        }
        System.out.println("---");

        while(true)
        {  
          System.out.print("Enter Command: ");
          String command=scan_tool.nextLine();


          if(command.equals("exit"))
          {
            System.out.println("Terminating...");
            break;
          }


          else if(command.equals("display all"))
          {
            for(int i=0; i<num_students; i++)
            {
                all_students[i].display();
            }
          }


          else if(command.startsWith("display"))
          {
            String name=command.substring(8).trim();
            int index=0;
            for(index=0; index<num_students; index++)
            {
                if(all_students[index].get_name().equals(name)) break;
            }
            if(index==num_students)
            {
                System.out.println("Student "+name+" does not exist.");
            }
            else
            {
                all_students[index].display();
            }
          }

          else if(command.startsWith("delete"))
        {
            String name=command.substring(7).trim();
            int index=0;
            for(index=0; index<num_students; index++)
            {
                if(all_students[index].get_name().equals(name)) break;
            }
            if(index==num_students)
            {
                System.out.println("Student "+name+" does not exist.");
            }

            else
            {
               Student[] all_students_after_delete= new Student[num_courses-1];
               int k=0;
               for(int i=0; i<num_courses-1; i++)
               {
                if(k==index) k++;
                all_students_after_delete[i]=all_students[k++];
               }
               System.out.println("Success, student "+all_students[index].get_name()+" deleted.");
               all_students=all_students_after_delete;
               num_students--;
            }
        }
        }
        
        scan_tool.close();
    }
}