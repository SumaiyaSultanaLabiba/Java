public class Student
{
    private String name;
    private double[] student_grades;
    private Course[] student_courses;
    private int num_courses;

    public Student(String name, double[] student_grades, Course[] student_courses, int num_courses)
    {
        this.name=name;
        this.student_grades=student_grades;
        this.student_courses=student_courses;
        this.num_courses=num_courses;
    }

    public String get_name()
    {
        return this.name;
    }

    public double[] get_student_grades()
    {
        return this.student_grades;
    }

    public void display()
    {
      System.out.println("Grades for "+this.name+":");
      for(int i=0; i<this.num_courses; i++)
      {
        System.out.println("-Course: "+this.student_courses[i].get_name()+", Grade: "+this.student_grades[i]);
      }
      System.out.println("-CGPA: "+this.get_cgpa());
    }

    public double get_cgpa()
    {
        double weighted=0;
        double total_credit_hour=0;

        for(int i=0; i<this.num_courses; i++)
        {
            weighted+=this.student_courses[i].get_credit_hour()*this.student_grades[i];
        }
        for(int i=0; i<this.num_courses; i++)
        {
            total_credit_hour+=this.student_courses[i].get_credit_hour();
        }
        return weighted/total_credit_hour;
    }
}