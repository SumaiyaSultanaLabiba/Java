/*
 * Parsing command line arguments...
Number of students: 3
Number of courses: 3
---
 
Course 1
Enter course name: CSE 101
Enter course credit: 3.0
 
Course 2
Enter course name: CSE 102
Enter course credit: 1.5
 
Course 3
Enter course name: CSE 103
Enter course credit: 3.0
---
 
Enter name of student 1: X  
Enter marks for CSE 101: 91  
Enter marks for CSE 102: 88  
Enter marks for CSE 201: 85  
 
Enter name of student 2: Y  
Enter marks for CSE 101: 99  
Enter marks for CSE 102: 99  
Enter marks for CSE 201: 99  
 
Enter name of student 3: Z  
Enter marks for CSE 101: 75  
Enter marks for CSE 102: 81  
Enter marks for CSE 201: 85  
---
 
Enter command: display all
 
Grades for X:  
- Course: CSE 101, Grade: 4.0  
- Course: CSE 102, Grade: 4.0  
- Course: CSE 201, Grade: 4.0  
- CGPA: 4.0
 
Grades for Y:  
- Course: CSE 101, Grade: 4.0  
- Course: CSE 102, Grade: 4.0  
- Course: CSE 201, Grade: 4.0  
- CGPA: 4.0
 
Grades for Z:  
- Course: CSE 101, Grade: 3.75  
- Course: CSE 102, Grade: 4.0  
- Course: CSE 201, Grade: 4.0  
- CGPA: 3.9 
---
 
Enter command: display P
 
Student P does not exist.
---
 
Enter command: display X
 
Grades for X:  
- Course: CSE 101, Grade: 4.0  
- Course: CSE 102, Grade: 4.0  
- Course: CSE 201, Grade: 4.0  
- CGPA: 4.0
---
 
Enter command: delete Z
Success, student Z deleted.
---
 
Enter command: display Z
Student Z does not exist.
---
 
Enter command: exit
 
Terminating...
 */