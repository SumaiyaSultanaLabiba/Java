public class Course
{
    private String name;
    private double credit_hour;

    public Course(String name, double credit_hour)
    {
        this.name=name;
        this.credit_hour=credit_hour;
    }

    public String get_name()
    {
        return this.name;
    }

    public double get_credit_hour()
    {
        return this.credit_hour;
    }

}