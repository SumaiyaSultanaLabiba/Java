import java.util.*;


public class Main
{
    public static void main(String[] args)
    {
        Scanner scan=new Scanner(System.in);
        int number_of_courses=Integer.parseInt(args[0]);
        while(number_of_courses>30)
        {
            System.out.print("The number of courses cannot exceed 30, enter correctly: ");
            number_of_courses=scan.nextInt();
            scan.nextLine();
        }

        Course all_courses[]=new Course[number_of_courses];
        Student all_students[]=new Student[100];
        int current_number_of_students=0;

        for(int i=0; i<number_of_courses; i++)
        {
            int course_ID=(i+1);
            System.out.print("Enter the name of the course "+(i+1)+": ");
            String course_name=scan.nextLine();
            System.out.print("Enter the seat capacity of the course "+(i+1)+": ");
            int course_seat_capacity=scan.nextInt();
            scan.nextLine();
            Course current_course=new Course(course_ID, course_name, course_seat_capacity);
            all_courses[i]=current_course;
        }

        while(true)
        {
            System.out.println("Choose an option from below: ");
            System.out.println("1. Enroll a New Student in a Course");
            System.out.println("2. Enroll Existing Student in a Course");
            System.out.println("3. Drop Student from a Course");
            System.out.println("4. Display All Courses with Enrolled Students");
            System.out.println("5. Exit");
            int option=scan.nextInt();
            scan.nextLine();

            if(option==1)
            {
                System.out.println("Enroll a New Student in a Course...........");
                System.out.print("Student ID: ");
                int student_ID=scan.nextInt();
                scan.nextLine();
                System.out.print("Student Name: ");
                String student_name=scan.nextLine();
                System.out.print("Course ID: ");
                int course_ID=scan.nextInt();
                scan.nextLine();
                Student enroll_student=new Student(student_ID, student_name);
                all_students[current_number_of_students]=enroll_student;
                current_number_of_students++;

                for(int i=0; i<number_of_courses; i++)
                {
                  if(all_courses[i].getID()==course_ID)
                  {
                    all_courses[i].enrollStudent(enroll_student);
                  }
                }
            }

            else if(option==2)
            {
                System.out.println("Enroll an existing Student in a Course...........");
                System.out.print("Student ID: ");
                int student_ID=scan.nextInt();
                scan.nextLine();
                System.out.print("Course ID: ");
                int course_ID=scan.nextInt();
                scan.nextLine();
                for(int i=0; i<current_number_of_students; i++)
                {
                    if(all_students[i].getID()==student_ID)
                    {
                        for(int j=0; j<number_of_courses; j++)
                        {
                            if(all_courses[j].getID()==course_ID)
                            {all_courses[j].enrollStudent(all_students[i]);
                            break;}
                        }
                        break;
                    }
                }
            }

            else if(option==3)
            {
                System.out.println("Drop an existing Student from a Course...........");
                System.out.print("Student ID: ");
                int student_ID=scan.nextInt();
                scan.nextLine();
                System.out.print("Course ID: ");
                int course_ID=scan.nextInt();
                scan.nextLine();  
                for(int i=0; i<current_number_of_students; i++)
                {
                    if(all_students[i].getID()==student_ID)
                    {
                        for(int j=0; j<number_of_courses; j++)
                        {
                            if(all_courses[j].getID()==course_ID)
                            {all_courses[j].dropStudent(all_students[i]);
                            break;}
                        }
                        break;
                    }
                }                                                                                                                                                                                                                                                                                                                                                                                                                                        
            }

            else if(option==4)
            {
              for(int i=0; i<number_of_courses; i++)
            {
                all_courses[i].display();
            }
            }

            else if(option==5)
            {
                System.out.println("Terminating..............");
                break;
            }
        }



        scan.close();
    }
}
