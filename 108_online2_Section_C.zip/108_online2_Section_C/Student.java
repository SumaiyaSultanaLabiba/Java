public class Student
{
    private int student_ID;
    private String student_name;

    public Student(int ID, String name)
    {
        this.student_ID=ID;
        this.student_name=name;
    }

    public int getID()
    {
        return this.student_ID;
    }

    public void display()
    {
        System.out.println("Student ID: "+this.student_ID+", Student name: "+this.student_name);
    }
}