public class Course
{
    private int course_ID;
    private String course_name;
    private int course_seat_capacity;
    private int current_number_of_students_enrolled;
    private Student all_students_enrolled[];


    public Course(int course_ID, String course_name, int course_seat_capacity)
    {
        this.course_ID=course_ID;
        this.course_name=course_name;
        this.course_seat_capacity=course_seat_capacity;
        this.current_number_of_students_enrolled=0;
        this.all_students_enrolled=new Student[course_seat_capacity];
    }

    public void display()
    {
        System.out.println("Course ID: "+this.course_ID);
        System.out.println("Course Name: "+this.course_name);
        System.out.println("Course Seat Capacity: "+this.course_seat_capacity);
        System.out.println("Current Enrollment Count: "+this.current_number_of_students_enrolled);
        if(this.current_number_of_students_enrolled==0)
        {
            System.out.println("No student enrolled.");
            return;
        }
        for(int i=0; i<this.current_number_of_students_enrolled; i++)
        {
            all_students_enrolled[i].display();
        }
    }

    public int getID()
    {
        return this.course_ID;
    }

    public void enrollStudent(Student student)
    {
      if(this.course_seat_capacity==this.current_number_of_students_enrolled)
      {
        System.out.println("Seat capacity of the course is reached; Cannot enroll new student");
        return;
      }
      for(int i=0; i<this.current_number_of_students_enrolled; i++)
      {
        if(all_students_enrolled[i].getID()==student.getID())
        {
            System.out.println("This student is already enrolled.");
            return;
        }
      }
      this.all_students_enrolled[this.current_number_of_students_enrolled]=student;
      this.current_number_of_students_enrolled++;
    }

    public void dropStudent(Student student)
    {
        for(int i=0; i<this.current_number_of_students_enrolled; i++)
        {
            if(all_students_enrolled[i].getID()==student.getID())
            {
                for(int j=i; j<current_number_of_students_enrolled-1; j++)
                {
                    all_students_enrolled[j]=all_students_enrolled[j+1];
                }
                this.current_number_of_students_enrolled--;
                return;
            }
        }
        System.out.println("Student is not enrolled in this course!!");
    }
}