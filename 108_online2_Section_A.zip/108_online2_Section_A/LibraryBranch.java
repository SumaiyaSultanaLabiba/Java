public class LibraryBranch
{
    private int branch_ID;
    private int maximum_number_of_books;
    private int total_number_of_books;
    private Book[] all_books;


    public LibraryBranch(int branch_ID, int maximum_number_of_books)
    {
        this.branch_ID=branch_ID;
        this.maximum_number_of_books=maximum_number_of_books;
        this.total_number_of_books=0;
        this.all_books=new Book[this.maximum_number_of_books];
    }

    public void display()
    {
        if(this.total_number_of_books==0)
        {
            System.out.println("No books available.");
            return;
        }
    
        for(int i=0; i<this.total_number_of_books; i++)
        {
            this.all_books[i].display();
        }
    }

    public int getID()
    {
        return this.branch_ID;
    }


    public void addBook(Book book)
    {
        if(this.total_number_of_books==this.maximum_number_of_books)
        {
            System.out.println("Limit reached!! No books can be added.");
            return;
        }
        this.all_books[this.total_number_of_books]=book;
        this.total_number_of_books++;
    }

    public void borrowBook(Book book)
    {
      for(int i=0; i<this.total_number_of_books; i++)
      {
        if(this.all_books[i].getID()==book.getID() && this.all_books[i].getAvailability()==true)
        {
            this.all_books[i].resetAvailability(false);
            return;
        }
      }
      System.out.println("This book is currently not available.");
    }

    public void returnBook(Book book)
    {
      for(int i=0; i<this.total_number_of_books; i++)
      {
        if(this.all_books[i].getID()==book.getID() && this.all_books[i].getAvailability()==false)
        {
            this.all_books[i].resetAvailability(true);
            return;
        }
      }
      System.out.println("Cannot return this book to this branch.");
    }

}
