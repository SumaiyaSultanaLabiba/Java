public class Book
{
    private int book_ID;
    private String book_title;
    private boolean book_availability;

    public Book(int book_ID, String book_title, boolean book_availability)
    {
      this.book_ID=book_ID;
      this.book_title=book_title;
      this.book_availability=book_availability;
    }

    public void display()
    {
        System.out.println("Book ID: "+this.book_ID+", Book Title: "+this.book_title+", Book Availability: "+this.book_availability);
    }

    public int getID()
    {
        return this.book_ID;
    }

    public void resetAvailability(boolean availability)
    {
        this.book_availability=availability;
    }

    public boolean getAvailability()
    {
        return this.book_availability;
    }
}
