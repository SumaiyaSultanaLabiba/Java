import java.util.*;

public class Main
{
    public static void main(String[] args)
    {
       Scanner scan= new Scanner(System.in);
       int number_of_branches=Integer.parseInt(args[0]);
       while(number_of_branches>10)
       {
        System.out.print("Number of branches cannot exceed 10, enter correctly: ");
        number_of_branches=scan.nextInt();
        scan.nextLine();
       }

       LibraryBranch all_branches[]=new LibraryBranch[number_of_branches];
       Book all_books[]=new Book[20*number_of_branches];
       int total_number_of_books=0;


       for(int i=0; i<number_of_branches; i++)
       {
         int branch_ID=(i+1);
         System.out.print("Enter the number of books in branch "+branch_ID+": ");
         int number_of_books=scan.nextInt();
         scan.nextLine();
         while(number_of_books>20)
         {
         System.out.print("The number of books in branch "+branch_ID+"cannot exceed 20, enter correctly: ");
         number_of_books=scan.nextInt();
         scan.nextLine();
         }

         LibraryBranch current_branch=new LibraryBranch(branch_ID, number_of_books);

         for(int j=0; j<number_of_books; j++)
         {
            System.out.print("Enter the book ID: ");
            int book_ID=scan.nextInt();
            scan.nextLine();
            System.out.print("Enter the book title: ");
            String book_title=scan.nextLine();
            System.out.print("Enter the book availability (true/false): ");
            boolean book_availability=scan.nextBoolean();
            scan.nextLine();
            Book current_book=new Book(book_ID, book_title, book_availability);
            all_books[total_number_of_books]=current_book;
            total_number_of_books++;
            current_branch.addBook(current_book);
         }
         
         all_branches[i]=current_branch;
       }


       while(true)
       {
         System.out.println("Choose an option from below: ");
         System.out.println("1. Borrow a Book ");
         System.out.println("2. Return a Book ");
         System.out.println("3. Display All Branch Info ");
         System.out.println("4. Exit ");
         int option=scan.nextInt();
         scan.nextLine();

         if(option==1)
         {
           System.out.print("Enter the book ID you want to borrow: ");
           int book_ID=scan.nextInt();
           scan.nextLine();
           System.out.print("Enter the branch ID from which you will borrow: ");
           int branch_ID=scan.nextInt();
           scan.nextLine();
           for(int i=0; i<number_of_branches; i++)
           {
            if(all_branches[i].getID()==branch_ID)
            {
               for(int j=0; j<total_number_of_books; j++)
               {
                 if(all_books[j].getID()==book_ID)
                 {
                  all_branches[i].borrowBook(all_books[j]);
                  break;
                 }
               }
               break;
            }
           }
         }

         else if(option==2)
         {
           System.out.print("Enter the book ID you want to return: ");
           int book_ID=scan.nextInt();
           scan.nextLine();
           System.out.print("Enter the branch ID where you will return: ");
           int branch_ID=scan.nextInt();
           scan.nextLine();
           for(int i=0; i<number_of_branches; i++)
           {
            if(all_branches[i].getID()==branch_ID)
            {
               for(int j=0; j<total_number_of_books; j++)
               {
                 if(all_books[j].getID()==book_ID)
                 {
                  all_branches[i].returnBook(all_books[j]);
                  break;
                 }
               }
               break;
            }
           }
         }

         else if(option==3)
         {
           for(int i=0; i<number_of_branches; i++)
           {
            System.out.println("The Branch ID: "+(i+1));
            all_branches[i].display();
           }
         }

         else
         {
            System.out.println("Exiting the program................ ");
            break;
         }
       }




       scan.close();
    }
}