public class Branch {

    private int id;
    private String name;
    private Account []  accounts;
    private int accountCount;
    // add your code here
    // there can be at most 20 branches  

     // you are not allowed to write any other constructor
    public Branch(int id, String name) {
        this.id = id;
        this.name = name;
        this.accountCount=0;
        this.accounts = new Account[20];
        // add your code here
    }

    public int getID()
    {
        return this.id;
    }

    public String getName()
    {
        return this.name;
    }

    public int getAccount()
    {
        return this.accountCount;
    }


    public void addAccount(Account a) {
        if(this.accountCount==20) System.out.println("No more account can be added to this branch");
        else accounts[accountCount++] = a;
    }


    // add your code here
    public double getBranchBalance()
    {
      double total_balance=0;
      for(int i=0; i<this.accountCount; i++)
      {
        total_balance+=this.accounts[i].getBalance();
      }
      return total_balance;
    }


    public Account getMinBalanceAccount()
    {
        double min_balance=this.accounts[0].getBalance();
        Account min_balance_holder=this.accounts[0];
        for(int i=0; i<this.accountCount; i++)
        {
          if(this.accounts[i].getBalance()<min_balance)
          {
            min_balance=this.accounts[i].getBalance();
            min_balance_holder=this.accounts[i];
          }
        }
        return min_balance_holder;
    }

    public static void transferBalance(Account a, Account b, double amount)
    {
      a.setBalance(a.getBalance()-amount);
      b.setBalance(b.getBalance()+amount);
    }


    public static void printAllBranchesInfo(Branch[] all_branches)
    {
       for(Branch element: all_branches)
       {
        System.out.println("Branch Id: "+element.getID()+", Branch Name: "+element.getName());
        for(int i=0; i<element.accountCount; i++)
        {
         System.out.print("Account Number: "+element.accounts[i].getNumber()+", ");
         System.out.print("Customer Name: "+element.accounts[i].getCustomer()+", ");
         System.out.println("Balance: "+String.format("%.2f", element.accounts[i].getBalance()));
        }
       }
    }
}
