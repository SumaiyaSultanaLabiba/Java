public class Account {

    private int number;
    private String customer;
    private double balance;
    // you are not allowed to add any more class variables here

    // you are not allowed to write any other constructor
    public Account(int number, String customer, double balance) {
        this.number = number;
        this.customer = customer;
        this.balance = balance;
    }

    // add your code here
    public String getCustomer()
    {
        return this.customer;
    }

    public double getBalance()
    {
        return this.balance;
    }

    public int getNumber()
    {
        return this.number;
    }

    public void setBalance(double amount)
    {
      this.balance=amount;
    }

    public void setCustomer(String name)
    {
      this.customer=name;
    }

    public void setNumber(int n)
    {
      this.number=n;
    }
}

